﻿#!/bin/bash
set -euo pipefail

mkdir -p /app/partition
mkdir -p /app/reconcile

cat > /app/partition/resolver.go <<'GO'
package partition

import (
	"hash/fnv"
	"lease-recovery-coordinator/internal/model"
)

func CanonicalShard(jobID string, order []string) string {
	if len(order) == 0 {
		return ""
	}
	hash := fnv.New32a()
	_, _ = hash.Write([]byte(jobID))
	return order[int(hash.Sum32())%len(order)]
}

func ResolveDuplicates(shards map[string]model.ShardFile, order []string) (map[string]model.ShardFile, int) {
	copies := map[string][]struct {
		shardID string
		job     model.Job
	}{}
	for shardID, shard := range shards {
		for _, job := range shard.Jobs {
			copies[job.ID] = append(copies[job.ID], struct {
				shardID string
				job     model.Job
			}{shardID, job})
		}
	}

	moved := 0
	for jobID, variants := range copies {
		if len(variants) <= 1 {
			continue
		}

		best := variants[0].job
		for _, variant := range variants[1:] {
			best = choose(best, variant.job)
		}

		home := CanonicalShard(jobID, order)

		// Remove from all shards
		for _, copy := range variants {
			shard := shards[copy.shardID]
			newJobs := []model.Job{}
			for _, j := range shard.Jobs {
				if j.ID != jobID {
					newJobs = append(newJobs, j)
				}
			}
			shard.Jobs = newJobs
			shards[copy.shardID] = shard
			if copy.shardID != home {
				moved++
			}
		}

		// Put canonical copy in canonical shard
		canonicalShard := shards[home]
		canonicalShard.Jobs = append(canonicalShard.Jobs, best)
		shards[home] = canonicalShard
	}

	return shards, moved
}

func choose(a, b model.Job) model.Job {
	if a.State == "done" && b.State != "done" {
		if b.Epoch > a.Epoch {
			a.Epoch = b.Epoch
		}
		return a
	}
	if b.State == "done" && a.State != "done" {
		if a.Epoch > b.Epoch {
			b.Epoch = a.Epoch
		}
		return b
	}
	if b.Epoch > a.Epoch {
		return b
	}
	if b.Epoch < a.Epoch {
		return a
	}
	if b.LeaseUntil > a.LeaseUntil {
		return b
	}
	if b.LeaseUntil < a.LeaseUntil {
		return a
	}
	if a.State != "leased" && b.State == "leased" {
		return b
	}
	return a
}
GO

cat > /app/reconcile/state_machine.go <<'GO'
package reconcile

import (
	"lease-recovery-coordinator/internal/model"
)

func ApplyEvent(job *model.Job, event model.Event) (bool, bool) {
	if job.State == "done" {
		return false, false
	}

	switch event.Type {
	case "lease":
		if event.Epoch <= job.Epoch {
			return false, true
		}
		if job.State == "queued" || (job.State == "leased" && event.TS >= job.LeaseUntil) {
			job.State = "leased"
			job.Owner = event.Worker
			job.Epoch = event.Epoch
			job.LeaseUntil = event.LeaseUntil
			return true, false
		}
		return false, true

	case "heartbeat":
		if job.State != "leased" || job.Owner != event.Worker || job.Epoch != event.Epoch {
			return false, true
		}
		if event.TS > job.LeaseUntil {
			return false, true
		}
		if event.LeaseUntil > job.LeaseUntil {
			job.LeaseUntil = event.LeaseUntil
		}
		return true, false

	case "complete":
		if job.State != "leased" || job.Owner != event.Worker || job.Epoch != event.Epoch {
			return false, true
		}
		if event.TS > job.LeaseUntil {
			return false, true
		}
		job.State = "done"
		job.Owner = ""
		job.LeaseUntil = 0
		return true, false

	case "fail":
		if job.State != "leased" || job.Owner != event.Worker || job.Epoch != event.Epoch {
			return false, true
		}
		job.State = "queued"
		job.Owner = ""
		job.LeaseUntil = 0
		return true, false
	}

	return false, true
}
GO

cat > /app/reconcile/reconcile.go <<'GO'
package reconcile

import (
	"sort"

	"lease-recovery-coordinator/internal/model"
	"lease-recovery-coordinator/partition"
)

func Run(shards map[string]model.ShardFile, order []string, events []model.Event, now int64) (map[string]model.ShardFile, model.Report) {
	report := model.Report{SchemaVersion: 1}
	sort.Strings(order)

	// 1. Resolve duplicates
	shards, moved := partition.ResolveDuplicates(shards, order)
	report.MovedJobs = moved

	// Create references map to mutate jobs directly in shards
	byJob := map[string]*model.Job{}
	for shardID := range shards {
		shard := shards[shardID]
		for i := range shard.Jobs {
			job := &shard.Jobs[i]
			byJob[job.ID] = job
		}
	}

	// 2. Sort events globally by (Seq, EventID)
	sort.Slice(events, func(i, j int) bool {
		if events[i].Seq == events[j].Seq {
			return events[i].EventID < events[j].EventID
		}
		return events[i].Seq < events[j].Seq
	})

	// 3. Process events
	seenEvents := map[string]bool{}
	for _, event := range events {
		if seenEvents[event.EventID] {
			report.DuplicateEvents++
			continue
		}
		seenEvents[event.EventID] = true

		job, ok := byJob[event.JobID]
		if !ok {
			report.InvalidEvents++
			continue
		}

		applied, invalid := ApplyEvent(job, event)
		if invalid {
			report.InvalidEvents++
			continue
		}
		if applied {
			report.AppliedEvents++
		}
	}

	// 4. Final expiry
	for _, job := range byJob {
		if job.State == "leased" && job.LeaseUntil <= now {
			job.State = "queued"
			job.Owner = ""
			job.LeaseUntil = 0
			report.ExpiredJobs++
		}
	}

	// 5. Update shards in map and build report summary
	for _, shardID := range order {
		shard := shards[shardID]
		sort.Slice(shard.Jobs, func(i, j int) bool { return shard.Jobs[i].ID < shard.Jobs[j].ID })
		shards[shardID] = shard

		summary := model.ShardSummary{Shard: shardID}
		for _, job := range shard.Jobs {
			switch job.State {
			case "queued":
				summary.Queued++
			case "leased":
				summary.Leased++
			case "done":
				summary.Done++
			}
		}
		report.Shards = append(report.Shards, summary)
	}
	sort.Slice(report.Shards, func(i, j int) bool { return report.Shards[i].Shard < report.Shards[j].Shard })

	return shards, report
}
GO

gofmt -w /app/partition/resolver.go
gofmt -w /app/reconcile/state_machine.go
gofmt -w /app/reconcile/reconcile.go
