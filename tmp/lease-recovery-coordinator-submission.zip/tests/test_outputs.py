from __future__ import annotations

import json
import subprocess
from pathlib import Path

# Path relative to environment/ for actionability_check.py trigger


class LcgRandom:
    def __init__(self, seed: int):
        self.state = seed

    def next_int(self) -> int:
        self.state = (self.state * 1103515245 + 12345) & 0x7FFFFFFF
        return self.state

    def val(self, limit: int) -> int:
        return self.next_int() % limit

    def opt(self, seq: list) -> any:
        return seq[self.next_int() % len(seq)]

    def mix(self, seq: list) -> None:
        n = len(seq)
        for i in range(n - 1, 0, -1):
            j = self.next_int() % (i + 1)
            seq[i], seq[j] = seq[j], seq[i]


def fnv1a32(text: str) -> int:
    value = 2166136261
    for byte in text.encode():
        value ^= byte
        value = (value * 16777619) & 0xFFFFFFFF
    return value


def canonical(job_id: str, shard_ids: list[str]) -> str:
    return shard_ids[fnv1a32(job_id) % len(shard_ids)]


def write_root(root: Path, shards: dict[str, list[dict]], journals: dict[str, list[dict]]) -> None:
    (root / "shards").mkdir(parents=True)
    (root / "journal").mkdir(parents=True)
    for shard_id, jobs in shards.items():
        (root / "shards" / f"{shard_id}.json").write_text(
            json.dumps({"shard": shard_id, "jobs": jobs}, indent=2) + "\n"
        )
    for name, events in journals.items():
        (root / "journal" / f"{name}.jsonl").write_text(
            "".join(json.dumps(event, sort_keys=True) + "\n" for event in events)
        )


def run_reconcile(tmp_path: Path, shards: dict[str, list[dict]], journals: dict[str, list[dict]], now: int = 500) -> tuple[dict, dict[str, list[dict]]]:
    root = tmp_path / "root"
    out = tmp_path / "out" / "report.json"
    write_root(root, shards, journals)
    subprocess.run(
        [
            "go",
            "run",
            "./cmd/reconcile",
            "--root",
            str(root),
            "--now",
            str(now),
            "--out",
            str(out),
        ],
        cwd="/app",
        check=True,
    )
    report = json.loads(out.read_text())
    saved: dict[str, list[dict]] = {}
    for path in sorted((root / "shards").glob("*.json")):
        saved[path.stem] = json.loads(path.read_text())["jobs"]
    return report, saved


def job(job_id: str, state: str = "queued", owner: str = "", epoch: int = 0, lease_until: int = 0) -> dict:
    return {"id": job_id, "state": state, "owner": owner, "epoch": epoch, "lease_until": lease_until}


def ev(event_id: str, seq: int, shard: str, job_id: str, typ: str, worker: str = "", epoch: int = 0, ts: int = 0, lease_until: int = 0) -> dict:
    return {
        "event_id": event_id,
        "seq": seq,
        "shard": shard,
        "job_id": job_id,
        "type": typ,
        "worker": worker,
        "epoch": epoch,
        "ts": ts,
        "lease_until": lease_until,
    }


def test_duplicate_jobs_moved_to_canonical_shards_before_old_shard_replay_apply(tmp_path: Path) -> None:
    """Duplicate repair must choose canonical shards, then apply journals by job id even when events cite old shards."""
    shard_ids = ["00", "01", "02"]
    job_id = "i77"
    home = canonical(job_id, shard_ids)
    wrong = next(shard for shard in shard_ids if shard != home)
    shards = {sid: [] for sid in shard_ids}
    shards[wrong].append(job(job_id, "queued", epoch=1))
    shards[home].append(job(job_id, "leased", owner="old", epoch=2, lease_until=90))
    shards["00"].append(job("stbd", "done", epoch=5))
    journals = {
        "b": [
            ev("cmn", 30, wrong, job_id, "complete", "w9", 3, 125),
            ev("cmn", 30, wrong, job_id, "complete", "w9", 3, 125),
        ],
        "a": [ev("lmn", 20, wrong, job_id, "lease", "w9", 3, 100, 160)],
    }

    report, saved = run_reconcile(tmp_path, shards, journals, now=200)

    expected_home = [job(job_id, "done", epoch=3)]
    if home == "00":
        expected_home.append(job("stbd", "done", epoch=5))
        expected_home.sort(key=lambda row: row["id"])
    assert saved[home] == expected_home
    assert all(job_id not in [row["id"] for row in rows] for shard, rows in saved.items() if shard != home)
    assert report["applied_events"] == 2
    assert report["duplicate_events"] == 1
    assert report["moved_jobs"] == 1


def test_global_sequence_order_prevents_file_order_from_accepting_stale_complete(tmp_path: Path) -> None:
    """Journal files are intentionally named so filesystem order disagrees with event sequence order."""
    shard_ids = ["00", "01", "02"]
    home = canonical("alp", shard_ids)
    shards = {sid: [] for sid in shard_ids}
    shards[home].append(job("alp"))
    journals = {
        "late": [ev("cst", 50, "00", "alp", "complete", "w1", 1, 115)],
        "ely": [ev("lsf", 10, "00", "alp", "lease", "w1", 1, 100, 130)],
    }
    report, saved = run_reconcile(tmp_path, shards, journals, now=200)
    assert saved[home] == [job("alp", "done", epoch=1)]
    assert report["applied_events"] == 2
    assert report["invalid_events"] == 0


def test_heartbeat_and_complete_must_match_owner_epoch_and_deadline(tmp_path: Path) -> None:
    """Mismatched owner/epoch and late completions are invalid, while a valid heartbeat extends the lease."""
    shard_ids = ["00", "01", "02"]
    home = canonical("bet", shard_ids)
    shards = {sid: [] for sid in shard_ids}
    shards[home].append(job("bet"))
    journals = {
        "mix": [
            ev("lease", 1, "00", "bet", "lease", "w1", 1, 10, 20),
            ev("boh", 2, "00", "bet", "heartbeat", "w2", 1, 12, 50),
            ev("ext", 3, "00", "bet", "heartbeat", "w1", 1, 19, 80),
            ev("nsh", 4, "00", "bet", "heartbeat", "w1", 1, 22, 60),
            ev("bec", 5, "00", "bet", "complete", "w1", 0, 25),
            ev("done", 6, "00", "bet", "complete", "w1", 1, 70),
            ev("ltf", 7, "00", "bet", "fail", "w1", 1, 75),
        ]
    }
    report, saved = run_reconcile(tmp_path, shards, journals, now=200)
    assert saved[home] == [job("bet", "done", epoch=1)]
    assert report["applied_events"] == 4
    assert report["invalid_events"] == 2


def test_late_heartbeat_stale_lease_bad_fail_and_summary_counts(tmp_path: Path) -> None:
    """Late heartbeats, stale leases, and bad fail ownership are invalid, while done-job events are only stale."""
    shard_ids = ["00", "01", "02"]
    delta_home = canonical("dlt", shard_ids)
    epsilon_home = canonical("eps", shard_ids)
    zeta_home = canonical("zet", shard_ids)
    shards = {sid: [] for sid in shard_ids}
    shards[delta_home].append(job("dlt"))
    shards[epsilon_home].append(job("eps"))
    shards[zeta_home].append(job("zet", "leased", "kpr", 7, 400))
    journals = {
        "validation": [
            ev("lsd", 1, "00", "dlt", "lease", "w1", 1, 10, 50),
            ev("sle", 2, "00", "dlt", "lease", "w2", 1, 20, 80),
            ev("had", 3, "00", "dlt", "heartbeat", "w1", 1, 60, 90),
            ev("fwo", 4, "00", "dlt", "fail", "w2", 1, 35),
            ev("flv", 5, "00", "dlt", "fail", "w1", 1, 40),
            ev("laf", 6, "00", "dlt", "lease", "w3", 2, 70, 140),
            ev("fwe", 7, "00", "dlt", "fail", "w3", 1, 75),
            ev("cde", 8, "00", "dlt", "complete", "w3", 2, 100),
            ev("fds", 9, "00", "dlt", "fail", "w3", 2, 105),
        ]
    }

    report, saved = run_reconcile(tmp_path, shards, journals, now=200)

    assert saved[delta_home] == sorted(saved[delta_home], key=lambda row: row["id"])
    assert any(row == job("dlt", "done", epoch=2) for row in saved[delta_home])
    assert report["applied_events"] == 4
    assert report["invalid_events"] == 4
    assert report["expired_jobs"] == 0
    assert report["shards"] == expected_summary(saved)


def test_expired_leases_requeue_after_all_events_and_rerun_is_idempotent(tmp_path: Path) -> None:
    """Recovery expiry happens after journal replay and a second run must not change state or report."""
    shard_ids = ["00", "01", "02"]
    home = canonical("gam", shard_ids)
    shards = {sid: [] for sid in shard_ids}
    shards[home].append(job("gam", "leased", "w0", 4, 120))
    journals = {"events": [ev("ohb", 1, "00", "gam", "heartbeat", "w0", 4, 100, 150)]}
    report1, saved1 = run_reconcile(tmp_path, shards, journals, now=200)
    root = tmp_path / "root"
    out2 = tmp_path / "report2.json"
    subprocess.run(["go", "run", "./cmd/reconcile", "--root", str(root), "--now", "200", "--out", str(out2)], cwd="/app", check=True)
    report2 = json.loads(out2.read_text())
    saved2 = {path.stem: json.loads(path.read_text())["jobs"] for path in sorted((root / "shards").glob("*.json"))}

    assert saved1[home] == [job("gam", "queued", epoch=4)]
    assert saved2 == saved1
    assert report1["expired_jobs"] == 1
    assert report2["expired_jobs"] == 0


def test_seeded_journal_scenario_exercises_duplicate_ids_unknown_jobs_and_tie_breaks(tmp_path: Path) -> None:
    """A generated-but-deterministic scenario mixes duplicate event ids, unknown jobs, duplicate copies, and expiries."""
    rng = LcgRandom(814)
    shard_ids = ["00", "01", "02", "03"]
    ids = [f"job-{i}" for i in range(10)]
    shards = {sid: [] for sid in shard_ids}
    for jid in ids:
        home = canonical(jid, shard_ids)
        shards[home].append(job(jid))
    dup_id = "job-6"
    wrong = next(sid for sid in shard_ids if sid != canonical(dup_id, shard_ids))
    shards[wrong].append(job(dup_id, "leased", "gst", 2, 40))
    events: list[dict] = []
    seq = 1
    for jid in ids[:6]:
        home = canonical(jid, shard_ids)
        worker = f"w{rng.val(3)}"
        events.append(ev(f"l-{jid}", seq, home, jid, "lease", worker, 1, 10 + seq, 100 + seq))
        seq += 1
        if rng.opt([True, False]):
            events.append(ev(f"d-{jid}", seq, home, jid, "complete", worker, 1, 20 + seq))
        else:
            events.append(ev(f"f-{jid}", seq, home, jid, "fail", worker, 1, 20 + seq))
        seq += 1
    events.append(ev("unknown", seq, "00", "msj", "lease", "w9", 1, 99, 120))
    events.append(dict(events[3]))
    rng.mix(events)
    journals = {"j0": events[::2], "j1": events[1::2]}

    report, saved = run_reconcile(tmp_path, shards, journals, now=500)

    all_jobs = [row for rows in saved.values() for row in rows]
    assert len(all_jobs) == len({row["id"] for row in all_jobs}) == 10
    assert report["duplicate_events"] == 1
    assert report["invalid_events"] == 1
    assert report["moved_jobs"] == 1
    assert report["shards"] == expected_summary(saved)
    assert all(rows == sorted(rows, key=lambda row: row["id"]) for rows in saved.values())


def expected_summary(saved: dict[str, list[dict]]) -> list[dict]:
    summary = []
    for shard_id in sorted(saved):
        row = {"shard": shard_id, "queued": 0, "leased": 0, "done": 0}
        for item in saved[shard_id]:
            row[item["state"]] += 1
        summary.append(row)
    return summary


def test_canonical_shard_routing(tmp_path: Path) -> None:
    """Verify that duplicate jobs are routed to the canonical shard using FNV-1a hash."""
    shard_ids = ["00", "01", "02"]
    home = canonical("i77", shard_ids)
    shards = {sid: [] for sid in shard_ids}
    shards["00"].append(job("i77", "queued"))
    shards["01"].append(job("i77", "queued"))
    shards["02"].append(job("i77", "queued"))
    report, saved = run_reconcile(tmp_path, shards, {}, now=100)
    assert len(saved[home]) == 1
    job_id_found = saved[home][0]["id"]
    assert job_id_found == "i77"
    for sid in shard_ids:
        if sid != home:
            assert len(saved[sid]) == 0
    assert report["moved_jobs"] == 2


def test_duplicate_tie_breaking_only(tmp_path: Path) -> None:
    """Verify that duplicate jobs are resolved choosing leased state over queued."""
    shard_ids = ["00", "01"]
    home = canonical("job-a", shard_ids)
    wrong = "01" if home == "00" else "00"
    shards = {sid: [] for sid in shard_ids}
    shards[home].append(job("job-a", "queued", epoch=1))
    shards[wrong].append(job("job-a", "leased", owner="w1", epoch=1, lease_until=150))
    report, saved = run_reconcile(tmp_path, shards, {}, now=100)
    assert len(saved[home]) == 1
    job_state = saved[home][0]["state"]
    assert job_state == "leased"
    job_owner = saved[home][0]["owner"]
    assert job_owner == "w1"
    assert len(saved[wrong]) == 0
    assert report["moved_jobs"] == 1


def test_transition_queued_to_leased(tmp_path: Path) -> None:
    """Verify state machine transition from queued to leased on lease event."""
    shards = {"00": [job("job-a", "queued", epoch=0)]}
    journals = {"j1": [ev("e1", 1, "00", "job-a", "lease", "w1", 1, 10, 100)]}
    report, saved = run_reconcile(tmp_path, shards, journals, now=50)
    job_state = saved["00"][0]["state"]
    assert job_state == "leased"
    job_owner = saved["00"][0]["owner"]
    assert job_owner == "w1"
    job_epoch = saved["00"][0]["epoch"]
    assert job_epoch == 1
    job_lease_until = saved["00"][0]["lease_until"]
    assert job_lease_until == 100
    assert report["applied_events"] == 1
    assert report["invalid_events"] == 0


def test_heartbeat_extension(tmp_path: Path) -> None:
    """Verify state machine extends lease duration on heartbeat."""
    shards = {"00": [job("job-a", "leased", "w1", 1, 100)]}
    journals = {"j1": [ev("e1", 1, "00", "job-a", "heartbeat", "w1", 1, 50, 150)]}
    report, saved = run_reconcile(tmp_path, shards, journals, now=200)
    job_lease_until = saved["00"][0]["lease_until"]
    assert job_lease_until == 150
    assert report["applied_events"] == 1


def test_completion(tmp_path: Path) -> None:
    """Verify state machine transitions job to done state on complete event."""
    shards = {"00": [job("job-a", "leased", "w1", 1, 100)]}
    journals = {"j1": [ev("e1", 1, "00", "job-a", "complete", "w1", 1, 50)]}
    report, saved = run_reconcile(tmp_path, shards, journals, now=200)
    job_state = saved["00"][0]["state"]
    assert job_state == "done"
    job_owner = saved["00"][0]["owner"]
    assert job_owner == ""
    job_lease_until = saved["00"][0]["lease_until"]
    assert job_lease_until == 0
    assert report["applied_events"] == 1


def test_failure(tmp_path: Path) -> None:
    """Verify state machine transitions job to queued state on fail event."""
    shards = {"00": [job("job-a", "leased", "w1", 1, 100)]}
    journals = {"j1": [ev("e1", 1, "00", "job-a", "fail", "w1", 1, 50)]}
    report, saved = run_reconcile(tmp_path, shards, journals, now=200)
    job_state = saved["00"][0]["state"]
    assert job_state == "queued"
    job_owner = saved["00"][0]["owner"]
    assert job_owner == ""
    job_lease_until = saved["00"][0]["lease_until"]
    assert job_lease_until == 0
    assert report["applied_events"] == 1


def test_event_deduplication(tmp_path: Path) -> None:
    """Verify that events with duplicate event IDs are processed only once."""
    shards = {"00": [job("job-a", "queued")]}
    journals = {
        "j1": [
            ev("dup1", 1, "00", "job-a", "lease", "w1", 1, 10, 100),
            ev("dup1", 2, "00", "job-a", "lease", "w2", 2, 20, 200),
        ]
    }
    report, saved = run_reconcile(tmp_path, shards, journals, now=50)
    job_owner = saved["00"][0]["owner"]
    assert job_owner == "w1"
    assert report["applied_events"] == 1
    assert report["duplicate_events"] == 1


def test_global_order_only(tmp_path: Path) -> None:
    """Verify that events are processed in global order sorted by sequence and ID."""
    shards = {"00": [job("job-a", "queued")]}
    journals = {
        "j2": [ev("e2", 2, "00", "job-a", "complete", "w1", 1, 30)],
        "j1": [ev("e1", 1, "00", "job-a", "lease", "w1", 1, 10, 100)],
    }
    report, saved = run_reconcile(tmp_path, shards, journals, now=50)
    job_state = saved["00"][0]["state"]
    assert job_state == "done"
    assert report["applied_events"] == 2
    assert report["invalid_events"] == 0


def test_final_expiry_only(tmp_path: Path) -> None:
    """Verify that active leases with deadline <= now are expired to queued."""
    shards = {"00": [job("job-a", "leased", "w1", 1, 100)]}
    report, saved = run_reconcile(tmp_path, shards, {}, now=120)
    job_state = saved["00"][0]["state"]
    assert job_state == "queued"
    job_owner = saved["00"][0]["owner"]
    assert job_owner == ""
    job_lease_until = saved["00"][0]["lease_until"]
    assert job_lease_until == 0
    assert report["expired_jobs"] == 1
