﻿package reconcile

import (
	"lease-recovery-coordinator/internal/model"
)

func ApplyEvent(job *model.Job, event model.Event) (bool, bool) {
	if job.State == "done" {
		return false, false
	}

	switch event.Type {
	case "lease":
		if job.State == "queued" || (job.State == "leased" && event.TS >= job.LeaseUntil) {
			if event.Epoch < job.Epoch {
				return false, true
			}
			job.State = "leased"
			job.Owner = event.Worker
			job.Epoch = event.Epoch
			job.LeaseUntil = event.LeaseUntil
			return true, false
		}
		return false, true

	case "heartbeat":
		if job.State == "leased" && job.Owner == event.Worker && job.Epoch == event.Epoch {
			if event.LeaseUntil > job.LeaseUntil {
				job.LeaseUntil = event.LeaseUntil
			}
			return true, false
		}
		return false, true

	case "complete":
		if job.State == "leased" && job.Owner == event.Worker && job.Epoch == event.Epoch {
			job.State = "done"
			job.Owner = ""
			job.LeaseUntil = 0
			return true, false
		}
		return false, true

	case "fail":
		if job.State == "leased" && job.Owner == event.Worker && job.Epoch == event.Epoch {
			job.State = "queued"
			job.LeaseUntil = 0
			return true, false
		}
		return false, true
	}

	return false, true
}
