﻿package reconcile

import (
	"sort"

	"lease-recovery-coordinator/internal/model"
	"lease-recovery-coordinator/partition"
)

func Run(shards map[string]model.ShardFile, order []string, events []model.Event, now int64) (map[string]model.ShardFile, model.Report) {
	report := model.Report{SchemaVersion: 1}

	shards, _ = partition.ResolveDuplicates(shards, order)

	byJob := map[string]*model.Job{}
	jobShard := map[string]string{}
	for shardID, shard := range shards {
		for i := range shard.Jobs {
			job := &shard.Jobs[i]
			byJob[job.ID] = job
			jobShard[job.ID] = shardID
		}
	}

	for _, event := range events {
		job, ok := byJob[event.JobID]
		if !ok {
			report.InvalidEvents++
			continue
		}

		applied, invalid := ApplyEvent(job, event)
		if invalid {
			report.InvalidEvents++
		} else if applied {
			report.AppliedEvents++
		}
	}

	for _, shardID := range order {
		shard := shards[shardID]
		summary := model.ShardSummary{Shard: shardID}
		for _, job := range shard.Jobs {
			switch job.State {
			case "queued":
				summary.Queued++
			case "leased":
				summary.Leased++
			case "done":
				summary.Done++
			}
		}
		report.Shards = append(report.Shards, summary)
	}
	sort.Slice(report.Shards, func(i, j int) bool { return report.Shards[i].Shard < report.Shards[j].Shard })

	return shards, report
}
