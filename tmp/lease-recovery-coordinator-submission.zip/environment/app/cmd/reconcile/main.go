package main

import (
	"flag"
	"fmt"
	"os"

	"lease-recovery-coordinator/reconcile"
	"lease-recovery-coordinator/internal/store"
)

func main() {
	root := flag.String("root", "", "coordinator root")
	now := flag.Int64("now", 0, "current unix timestamp")
	out := flag.String("out", "", "report path")
	flag.Parse()
	if *root == "" || *out == "" {
		fmt.Fprintln(os.Stderr, "root and out are required")
		os.Exit(2)
	}
	shards, order, err := store.LoadShards(*root)
	if err != nil {
		fmt.Fprintf(os.Stderr, "load shards: %v\n", err)
		os.Exit(1)
	}
	events, err := store.LoadEvents(*root)
	if err != nil {
		fmt.Fprintf(os.Stderr, "load events: %v\n", err)
		os.Exit(1)
	}
	updated, report := reconcile.Run(shards, order, events, *now)
	if err := store.WriteShards(*root, updated); err != nil {
		fmt.Fprintf(os.Stderr, "write shards: %v\n", err)
		os.Exit(1)
	}
	if err := store.WriteReport(*out, report); err != nil {
		fmt.Fprintf(os.Stderr, "write report: %v\n", err)
		os.Exit(1)
	}
}
