package model

type Job struct {
	ID         string `json:"id"`
	State      string `json:"state"`
	Owner      string `json:"owner"`
	Epoch      int    `json:"epoch"`
	LeaseUntil int64  `json:"lease_until"`
}

type ShardFile struct {
	Shard string `json:"shard"`
	Jobs  []Job  `json:"jobs"`
}

type Event struct {
	EventID    string `json:"event_id"`
	Seq        int    `json:"seq"`
	Shard      string `json:"shard"`
	JobID      string `json:"job_id"`
	Type       string `json:"type"`
	Worker     string `json:"worker"`
	Epoch      int    `json:"epoch"`
	TS         int64  `json:"ts"`
	LeaseUntil int64  `json:"lease_until"`
}

type ShardSummary struct {
	Shard  string `json:"shard"`
	Queued int    `json:"queued"`
	Leased int    `json:"leased"`
	Done   int    `json:"done"`
}

type Report struct {
	SchemaVersion  int            `json:"schema_version"`
	Shards         []ShardSummary `json:"shards"`
	AppliedEvents  int            `json:"applied_events"`
	DuplicateEvents int            `json:"duplicate_events"`
	InvalidEvents int             `json:"invalid_events"`
	ExpiredJobs   int             `json:"expired_jobs"`
	MovedJobs     int             `json:"moved_jobs"`
}
