package store

import (
	"bufio"
	"encoding/json"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"lease-recovery-coordinator/internal/model"
)

func LoadShards(root string) (map[string]model.ShardFile, []string, error) {
	pattern := filepath.Join(root, "shards", "*.json")
	paths, err := filepath.Glob(pattern)
	if err != nil {
		return nil, nil, err
	}
	sort.Strings(paths)
	shards := map[string]model.ShardFile{}
	order := []string{}
	for _, path := range paths {
		data, err := os.ReadFile(path)
		if err != nil {
			return nil, nil, err
		}
		var shard model.ShardFile
		if err := json.Unmarshal(data, &shard); err != nil {
			return nil, nil, err
		}
		shards[shard.Shard] = shard
		order = append(order, shard.Shard)
	}
	return shards, order, nil
}

func LoadEvents(root string) ([]model.Event, error) {
	paths, err := filepath.Glob(filepath.Join(root, "journal", "*.jsonl"))
	if err != nil {
		return nil, err
	}
	sort.Strings(paths)
	events := []model.Event{}
	for _, path := range paths {
		file, err := os.Open(path)
		if err != nil {
			return nil, err
		}
		scanner := bufio.NewScanner(file)
		for scanner.Scan() {
			line := strings.TrimSpace(scanner.Text())
			if line == "" {
				continue
			}
			var event model.Event
			if err := json.Unmarshal([]byte(line), &event); err != nil {
				_ = file.Close()
				return nil, err
			}
			events = append(events, event)
		}
		if err := scanner.Err(); err != nil {
			_ = file.Close()
			return nil, err
		}
		_ = file.Close()
	}
	return events, nil
}

func WriteShards(root string, shards map[string]model.ShardFile) error {
	for id, shard := range shards {
		sort.Slice(shard.Jobs, func(i, j int) bool { return shard.Jobs[i].ID < shard.Jobs[j].ID })
		data, err := json.MarshalIndent(shard, "", "  ")
		if err != nil {
			return err
		}
		path := filepath.Join(root, "shards", id+".json")
		if err := os.WriteFile(path, append(data, '\n'), 0o644); err != nil {
			return err
		}
	}
	return nil
}

func WriteReport(path string, report model.Report) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	data, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, append(data, '\n'), 0o644)
}
