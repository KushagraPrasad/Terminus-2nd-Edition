module lease-recovery-coordinator

go 1.22
