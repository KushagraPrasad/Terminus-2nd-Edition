# Lease Recovery Contract

The coordinator stores job state in `root/shards/*.json` and append-only worker journals in `root/journal/*.jsonl`. Recovery is run after crashes and partial writes. It must be deterministic and idempotent for persisted state: running it twice with the same `--now` must leave the same shard files. The report describes what the current run applied, skipped, repaired, or expired.

## Shard State

Each shard file is JSON:

```json
{
  "shard": "00",
  "jobs": [
    {"id": "job-a", "state": "queued", "owner": "", "epoch": 0, "lease_until": 0}
  ]
}
```

`state` is `queued`, `leased`, or `done`. `owner` is empty unless the job is leased. `epoch` is a monotonically increasing lease generation. `lease_until` is a Unix timestamp and is meaningful only for leased jobs.

## Journal Events

Every non-empty line in `root/journal/*.jsonl` is a JSON object:

```json
{"event_id":"e1","seq":10,"shard":"00","job_id":"job-a","type":"lease","worker":"w1","epoch":1,"ts":100,"lease_until":130}
```

Valid types are `lease`, `heartbeat`, `complete`, and `fail`.

Apply all journal events in global order by `(seq, event_id)`, regardless of which journal file contains them. Duplicate `event_id` values are idempotent: apply only the first event in that global order and count later duplicates in the report.

Events for unknown jobs are invalid. Events that fail the acceptance rule for their type are also invalid. Invalid events are skipped and counted in `invalid_events`, but they must not stop recovery.

## Event Semantics

`lease`: accepted only when the job is `queued`, or when it is `leased` but the prior lease had expired at the event timestamp (`ts >= lease_until`). An accepted lease sets `state=leased`, `owner=worker`, `epoch=epoch`, and `lease_until=lease_until`. Reject stale leases whose epoch is less than or equal to the job's current epoch.

`heartbeat`: accepted only when the job is currently leased by the same worker and epoch, and the heartbeat timestamp is not after the current lease deadline (`ts <= lease_until`). An accepted heartbeat extends `lease_until` to the event's `lease_until` only if it is later than the current deadline.

`complete`: accepted only when the job is currently leased by the same worker and epoch and `ts <= lease_until`. It sets `state=done`, clears owner, and sets `lease_until=0`. Once a job is done, later events for that job are ignored as stale. Stale events after `done` are not invalid and must not increment `invalid_events`.

`fail`: accepted only when the job is currently leased by the same worker and epoch. It returns the job to `queued`, clears owner, and sets `lease_until=0`; the epoch is retained.

After all journals are applied, any remaining leased job with `lease_until <= --now` expires back to `queued`, with owner cleared and `lease_until=0`.

## Duplicate Jobs Across Shards

Crash bugs may leave the same job id in more than one shard file. The canonical shard is selected with FNV-1a 32-bit hash of the job id modulo the number of shard files, using lexicographic shard filename order. Reconcile duplicates before applying journals:

- If any copy is `done`, the canonical job is `done` with the highest epoch seen.
- Otherwise, choose the copy with the highest epoch; ties choose the copy with the later `lease_until`; remaining ties choose `leased` over `queued`.
- Remove all non-canonical copies.

Journal events may name the old shard. Match them by `job_id`; do not require the event shard to equal the canonical shard after duplicate repair.

## Output And Atomicity

Write every shard file back sorted by job id. Replace stale or duplicate entries rather than merging them. Shards containing no jobs must write the `jobs` key as an empty JSON array `[]` instead of a `null` value.

Write the report JSON after successful shard writes:

```json
{
  "schema_version": 1,
  "shards": [{"shard":"00","queued":1,"leased":0,"done":2}],
  "applied_events": 4,
  "duplicate_events": 1,
  "invalid_events": 0,
  "expired_jobs": 1,
  "moved_jobs": 2
}
```

Sort `shards` by shard id. `moved_jobs` counts job copies removed from non-canonical shards during duplicate repair. The report field `applied_events` counts successfully processed events, and the `duplicate_events` field counts duplicate IDs. The command should exit non-zero only when files cannot be read, parsed, or written; semantic journal problems are counted as invalid events instead.
