﻿package partition

import (
	"lease-recovery-coordinator/internal/model"
)

func CanonicalShard(jobID string, order []string) string {
	if len(order) == 0 {
		return ""
	}
	var hash uint32 = 2166136261
	for i := 0; i < len(jobID); i++ {
		hash *= 16777619
		hash ^= uint32(jobID[i])
	}
	return order[hash % uint32(len(order))]
}

func ResolveDuplicates(shards map[string]model.ShardFile, order []string) (map[string]model.ShardFile, int) {
	byJob := map[string][]struct {
		shardID string
		index   int
		job     model.Job
	}{}

	for shardID, shard := range shards {
		for i, job := range shard.Jobs {
			byJob[job.ID] = append(byJob[job.ID], struct {
				shardID string
				index   int
				job     model.Job
			}{shardID, i, job})
		}
	}

	moved := 0
	for jobID, copies := range byJob {
		if len(copies) <= 1 {
			continue
		}

		canonicalID := CanonicalShard(jobID, order)

		var best model.Job
		hasDone := false
		highestEpoch := -1

		for _, copy := range copies {
			if copy.job.State == "done" {
				hasDone = true
			}
			if copy.job.Epoch > highestEpoch {
				highestEpoch = copy.job.Epoch
			}
		}

		if hasDone {
			best = model.Job{
				ID:         jobID,
				State:      "done",
				Epoch:      highestEpoch,
				LeaseUntil: 0,
			}
		} else {
			best = copies[0].job
			for i := 1; i < len(copies); i++ {
				c := copies[i].job
				if c.Epoch > best.Epoch {
					best = c
				} else if c.Epoch == best.Epoch {
					if c.LeaseUntil > best.LeaseUntil {
						best = c
					} else if c.LeaseUntil == best.LeaseUntil {
						if c.State == "queued" && best.State == "leased" {
							best = c
						}
					}
				}
			}
		}

		// Remove from all shards
		for _, copy := range copies {
			shard := shards[copy.shardID]
			newJobs := []model.Job{}
			for _, j := range shard.Jobs {
				if j.ID != jobID {
					newJobs = append(newJobs, j)
				}
			}
			shard.Jobs = newJobs
			shards[copy.shardID] = shard
			if copy.shardID != canonicalID {
				moved++
			}
		}

		// Put canonical copy in canonical shard
		canonicalShard := shards[canonicalID]
		canonicalShard.Jobs = append(canonicalShard.Jobs, best)
		shards[canonicalID] = canonicalShard
	}

	return shards, moved
}
