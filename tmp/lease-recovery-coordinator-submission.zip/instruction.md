I need the local lease recovery coordinator in `/app` repaired. The command under test is:

```bash
go run /app/cmd/reconcile --root <coordinator-root> --now 1700000000 --out /app/out/report.json
```

The recovery contract is in `/app/docs/recovery_contract.md`. Please fix the implementation so it can reconcile a crash-recovered coordinator root with multiple shard files and worker journals. The current implementation fails to resolve duplicate jobs across shards, ignores global sequence ordering of events, and lacks required epoch and timestamp validations for event acceptance.

Keep the CLI flags, shard JSON schema, and report JSON schema stable. Do not hardcode the sample data or assume a fixed number of shards. Static or manual output writes are insufficient; the Go source code inside the reconciliation subsystem under `/app/internal/reconcile` must be modified/repaired so that all verifier checks pass. Please fix the source code. The reconciliation module functions and library behavior must be correct.
