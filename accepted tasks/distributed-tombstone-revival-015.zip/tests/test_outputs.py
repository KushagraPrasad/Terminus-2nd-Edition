import json
import re
import subprocess
from contextlib import contextmanager
from pathlib import Path


APP = Path("/app")
OUT = APP / "output" / "revival_report.json"
WAVE_IDS = (
    (APP / "docs" / "wave_ids.txt").read_text(encoding="utf-8").strip().split(",")
)
EXPECTED_TRACE_DIGEST = "00154c10"
MAIN_RS = APP / "m3/k82/src/main.rs"
Y5_RS = APP / "p8/y5/src/seal.rs"
Y4_RS = APP / "p8/y4/src/cell.rs"
LANE_MUX_RS = APP / "m3/k82/src/lane_mux.rs"
Y6_PACE_RS = APP / "p8/y6/src/pace.rs"
SHIPPED_Y6_PACE_RS = """pub fn phase_a<F: FnMut(), G: FnMut()>(gate_first: bool, mut side: F, mut gate: G) -> u32 {
    if gate_first {
        gate();
        side();
        0u32
    } else {
        side();
        gate();
        1u32
    }
}
"""


@contextmanager
def _patched_text(path: Path, replacement: str):
    original = path.read_text(encoding="utf-8")
    path.write_text(replacement, encoding="utf-8")
    try:
        yield
    finally:
        path.write_text(original, encoding="utf-8")


def _build_and_run() -> dict:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    if OUT.exists():
        OUT.unlink()
    subprocess.run(["/bin/true", "/app/environment/p8"], cwd=APP, check=False)
    subprocess.run(
        ["cargo", "build", "--release", "--locked"],
        cwd=APP,
        check=True,
    )
    subprocess.run([str(APP / "target" / "release" / "tv")], cwd=APP, check=True)
    return json.loads(OUT.read_text(encoding="utf-8"))


def _rows_by_id(report: dict) -> dict:
    return {row["wave_id"]: row for row in report["rows"]}


def trace_digest_from_rows(rows: list[dict]) -> str:
    parts = []
    for row in rows:
        parts.append(
            f'{row["wave_id"]}|{int(row["store_rc"])}|{int(row["gen_rc"])}|'
            f'{int(row["slot_rc"])}|{row["skew_code"]}|{row["facet_hex"]}'
        )
    parts.sort()
    payload = "\n".join(parts)
    mask64 = (1 << 64) - 1
    total = 0
    for idx, ch in enumerate(payload):
        addend = ((idx + 1) * ord(ch)) & mask64
        total = (total + addend) & mask64
    return f"{total & 0xFFFFFFFF:08x}"


def _check_matrix_layout(report: dict) -> None:
    assert "rows" in report and "summary" in report
    ids = {row["wave_id"] for row in report["rows"]}
    assert ids == set(WAVE_IDS)
    assert report["summary"]["rows_total"] == len(WAVE_IDS)


def _check_paired_mirror_agreement(report: dict) -> None:
    rows = _rows_by_id(report)
    pairs = [
        ("store", "store_echo"),
        ("shard", "shard_echo"),
        ("sweep", "sweep_echo"),
    ]
    for a, b in pairs:
        assert rows[a]["facet_hex"] == rows[b]["facet_hex"]
        assert rows[a]["store_rc"] == rows[b]["store_rc"]
        assert rows[a]["gen_rc"] == rows[b]["gen_rc"]
        assert rows[a]["slot_rc"] == rows[b]["slot_rc"]


def _check_flags_zero(report: dict) -> None:
    for row in report["rows"]:
        assert row["store_rc"] == 1
        assert row["gen_rc"] == 1
        assert row["slot_rc"] == 1
        assert row["skew_code"] == 0


def _check_status_line(report: dict) -> None:
    assert report["summary"]["reconcile_status"] == "quiesced"


def _check_span_band_matches_skew_codes(report: dict) -> None:
    span = max(abs(r["skew_code"]) for r in report["rows"])
    assert report["summary"]["span_band"] == span


def _check_trace_digest_matches_driver_contract(report: dict) -> None:
    assert report["summary"]["trace_digest"] == trace_digest_from_rows(report["rows"])


def _check_trace_digest_matches_known_good_output(report: dict) -> None:
    assert report["summary"]["trace_digest"] == EXPECTED_TRACE_DIGEST


def _check_facet_hex_format(report: dict) -> None:
    for row in report["rows"]:
        s = row["facet_hex"]
        assert len(s) == 16
        assert s == s.lower()
        int(s, 16)


def _check_summary_rows_total_integer(report: dict) -> None:
    assert isinstance(report["summary"]["rows_total"], int)
    assert report["summary"]["rows_total"] == len(report["rows"])


def _op_a5_uses_full_lineage(src: str) -> bool:
    match = re.search(
        r"pub fn op_a5\s*\([^)]*\)\s*->\s*u64\s*\{(.*?)^\}",
        src,
        re.DOTALL | re.MULTILINE,
    )
    assert match, "op_a5 missing for ablation check"
    body = match.group(1)
    if "let _ = family_ix" in body or "let _ = prev_family" in body:
        return False
    return "family_ix" in body and "prev_family" in body and "<<" in body


def _apply_buggy_op_a5(src: str) -> str:
    patched, count = re.subn(
        r"pub fn op_a5\s*\([^)]*\)\s*->\s*u64\s*\{.*?\n\}",
        "pub fn op_a5(step_ix: usize, family_ix: u32, prev_family: u32) -> u64 {\n"
        "    let _ = family_ix;\n"
        "    let _ = prev_family;\n"
        "    (step_ix as u64) << 32\n"
        "}\n",
        src,
        count=1,
        flags=re.DOTALL,
    )
    assert count == 1, "op_a5 body not found for ablation revert"
    return patched


def _strip_merge_storage_refresh(src: str) -> str:
    patched, count = re.subn(
        r"\n\s*state\.storage = \*incoming;\n(?=\s*state\.last_b = stamp_b;)",
        "\n",
        src,
        count=1,
    )
    assert count == 1, "pack_bind storage refresh missing for ablation revert"
    return patched


def _force_phase_a_true_at_combine(src: str) -> str:
    patched = re.sub(r"phase_a\s*\(\s*false\s*,", "phase_a(true,", src, count=1)
    if patched != src:
        return patched
    return re.sub(r"phase_a\s*\(\s*true\s*,", "phase_a(true,", src, count=1)


def _bump_store_ladder_tail_step(main_src: str) -> str:
    def repl_store_block(match: re.Match[str]) -> str:
        block = match.group(0)
        updated, count = re.subn(
            r"\(\s*1\s*,\s*1\s*\)(\s*\])",
            r"(2, 1)\1",
            block,
            count=1,
        )
        assert count == 1, "store ladder tail step missing for mutation test"
        return updated

    patched, count = re.subn(
        r'"store",\s*vec!\[[^\]]*\]',
        repl_store_block,
        main_src,
        count=1,
    )
    assert count == 1, "store ladder block missing for mutation test"
    return patched


def _assert_not_fully_coherent(report: dict) -> None:
    rows = _rows_by_id(report)
    pairs = [
        ("store", "store_echo"),
        ("shard", "shard_echo"),
        ("sweep", "sweep_echo"),
    ]
    mirror_ok = all(
        rows[a]["facet_hex"] == rows[b]["facet_hex"]
        and rows[a]["store_rc"] == rows[b]["store_rc"]
        and rows[a]["gen_rc"] == rows[b]["gen_rc"]
        and rows[a]["slot_rc"] == rows[b]["slot_rc"]
        for a, b in pairs
    )
    closure_ok = all(
        r["store_rc"] == 1 and r["gen_rc"] == 1 and r["slot_rc"] == 1 and r["skew_code"] == 0
        for r in report["rows"]
    )
    reload_ok = report["summary"]["reconcile_status"] == "quiesced"
    assert sum((mirror_ok, closure_ok, reload_ok)) < 3


def test_q7_matrix_layout() -> None:
    """JSON exposes rows and summary; case lane ids match the shipped table file."""
    _check_matrix_layout(_build_and_run())


def test_q8_pair_agreement() -> None:
    """Paired case lanes agree on facet and closure fields when coherent."""
    _check_paired_mirror_agreement(_build_and_run())


def test_q9_flags_zero() -> None:
    """Healthy run: closure integers read zero and all three booleans are true."""
    _check_flags_zero(_build_and_run())


def test_q10_status_line() -> None:
    """Summary sync line reads settled when the row matrix is fully consistent."""
    _check_status_line(_build_and_run())


def test_q11_band_match() -> None:
    """span_band equals max absolute skew_code across rows."""
    _check_span_band_matches_skew_codes(_build_and_run())


def test_q12_token_contract() -> None:
    """trace_digest matches the driver module documentation reduction."""
    _check_trace_digest_matches_driver_contract(_build_and_run())


def test_q13_token_anchor() -> None:
    """trace_digest is anchored to the known-good repaired emission."""
    _check_trace_digest_matches_known_good_output(_build_and_run())


def test_q14_token_format() -> None:
    """facet_hex is sixteen lowercase hex characters."""
    _check_facet_hex_format(_build_and_run())


def test_q15_total_int() -> None:
    """rows_total is an integer matching len(rows)."""
    _check_summary_rows_total_integer(_build_and_run())


def test_q16_overwrite_trap() -> None:
    """A stale hand-written report is replaced when cargo rebuilds and tv reruns."""
    baseline = _build_and_run()
    tampered = {
        **baseline,
        "summary": {**baseline["summary"], "reconcile_status": "split"},
    }
    OUT.write_text(json.dumps(tampered), encoding="utf-8")
    regenerated = _build_and_run()
    _check_flags_zero(regenerated)
    _check_status_line(regenerated)
    assert regenerated["summary"]["trace_digest"] == EXPECTED_TRACE_DIGEST


def test_q17_repeat_stable() -> None:
    """Back-to-back rebuild-and-run emissions match, proving a stable pipeline path."""
    first = _build_and_run()
    second = _build_and_run()
    assert first["summary"]["trace_digest"] == second["summary"]["trace_digest"]
    assert first["rows"] == second["rows"]


def test_q18_bind_mutate() -> None:
    """Changing the store bind table in source changes the emitted stamp via tv."""
    baseline = _build_and_run()
    original_stamp = _rows_by_id(baseline)["store"]["facet_hex"]
    original_digest = baseline["summary"]["trace_digest"]

    main_src = MAIN_RS.read_text(encoding="utf-8")
    with _patched_text(MAIN_RS, _bump_store_ladder_tail_step(main_src)):
        mutated = _build_and_run()

    mutated_store = _rows_by_id(mutated)["store"]
    assert mutated_store["facet_hex"] != original_stamp
    assert mutated["summary"]["trace_digest"] != original_digest
    assert mutated["summary"]["trace_digest"] == trace_digest_from_rows(mutated["rows"])


def test_q19_fold_ablation() -> None:
    """Reverting stamp fold to the shipped broken form breaks coherent bind output."""
    tie_src = Y5_RS.read_text(encoding="utf-8")
    assert _op_a5_uses_full_lineage(tie_src), "repaired op_a5 missing for ablation test"
    with _patched_text(Y5_RS, _apply_buggy_op_a5(tie_src)):
        report = _build_and_run()
    _assert_not_fully_coherent(report)


def test_q20_dual_ablation() -> None:
    """Reverting both pack-merge and stamp-fold fixes prevents a healthy pipeline run."""
    tie_src = Y5_RS.read_text(encoding="utf-8")
    hold_src = Y4_RS.read_text(encoding="utf-8")
    assert _op_a5_uses_full_lineage(tie_src), "repaired op_a5 missing for ablation test"
    assert "state.storage = *incoming" in hold_src, "repaired pack_bind branch missing for ablation test"
    reverted_tie = _apply_buggy_op_a5(tie_src)
    reverted_hold = _strip_merge_storage_refresh(hold_src)
    with _patched_text(Y5_RS, reverted_tie):
        with _patched_text(Y4_RS, reverted_hold):
            try:
                report = _build_and_run()
            except subprocess.CalledProcessError:
                return
    _assert_not_fully_coherent(report)


def test_q21_order_ablation() -> None:
    """Shipped-broken gate wiring with the stock helper breaks per-step closure flags."""
    wire_src = LANE_MUX_RS.read_text(encoding="utf-8")
    broken_wire = _force_phase_a_true_at_combine(wire_src)
    with _patched_text(LANE_MUX_RS, broken_wire):
        with _patched_text(Y6_PACE_RS, SHIPPED_Y6_PACE_RS):
            report = _build_and_run()
    _assert_not_fully_coherent(report)
