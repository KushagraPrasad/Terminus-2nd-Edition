use super::PackState;

pub fn buffer_slice(_state: &PackState, lane: usize) -> f64 {
    (lane as f64) * 0.01
}
