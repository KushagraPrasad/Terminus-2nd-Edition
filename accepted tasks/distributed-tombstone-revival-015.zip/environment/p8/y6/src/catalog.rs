pub const CASE_LANE_TABLE: [&str; 6] = [
    "store",
    "store_echo",
    "shard",
    "shard_echo",
    "sweep",
    "sweep_echo",
];
