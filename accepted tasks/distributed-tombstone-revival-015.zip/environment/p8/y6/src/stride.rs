pub fn scan_window(tags: &[u32], width: usize) -> u32 {
    let mut acc = 0u32;
    for (idx, tag) in tags.iter().take(width).enumerate() {
        acc = acc.wrapping_add(*tag ^ (idx as u32 + 1));
    }
    acc
}
