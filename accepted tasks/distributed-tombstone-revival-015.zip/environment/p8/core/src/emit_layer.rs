pub struct SeedBundle {
    pub ladder_tag: u64,
    pub channel_tag: u64,
}

pub struct RowAdjust {
    pub wave_id: String,
    pub store_rc: i32,
    pub gen_rc: i32,
    pub slot_rc: i32,
}

pub fn seed_digest(bundle: &SeedBundle) -> u64 {
    bundle.ladder_tag.wrapping_mul(0x9e37_79b9).wrapping_add(bundle.channel_tag)
}

pub fn op_b2(rows: &mut [RowAdjust], bundle: &SeedBundle, pack_tag: u64) {
    let expect = seed_digest(bundle);
    if pack_tag != expect {
        for row in rows.iter_mut() {
            if row.wave_id.starts_with("shard") || row.wave_id.starts_with("sweep") {
                row.gen_rc = 0;
            }
        }
    }
}
