use yd66::phase_a;

pub fn lane_mux<F: FnMut(), G: FnMut()>(side: F, gate: G) -> u32 {
    phase_a(true, side, gate)
}
