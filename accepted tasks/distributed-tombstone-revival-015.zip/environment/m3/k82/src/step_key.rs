use yc55::op_a5;

pub fn step_key(step_ix: usize, fam_ix: u32, prev: u32) -> u64 {
    op_a5(step_ix, fam_ix, prev)
}
