# Revival report contract

The driver writes JSON at `/app/output/revival_report.json` with top-level `rows` and `summary`.

Each row carries: wave_id (string), store_rc (integer 0 or 1), gen_rc (integer 0 or 1), slot_rc (integer 0 or 1), skew_code (integer), facet_hex (exactly 16 lowercase hexadecimal digits).

Summary carries: rows_total (integer count of rows), reconcile_status (string), span_band (integer), trace_digest (eight lowercase hexadecimal digits).

Mirror pairs: store with store_echo, shard with shard_echo, sweep with sweep_echo.

Coherent emissions: every skew_code is 0, all three closure counters are 1 on every row, paired rows share facet_hex, and reconcile_status reads quiesced.
