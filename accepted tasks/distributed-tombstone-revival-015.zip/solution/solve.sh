#!/usr/bin/env bash
set -euo pipefail

log() { printf '[solve] %s\n' "$1"; }

cd /app
mkdir -p /app/output
rm -f /app/output/revival_report.json

log "apply source fixes"
cd /solution
patch -d /app -p0 --batch < oracle.patch
cd /app
cargo build --release --locked
/app/target/release/tv

log "sanity-check output contract"
python3 <<'PY'
import json
from pathlib import Path

data = json.loads(Path("/app/output/revival_report.json").read_text(encoding="utf-8"))
assert data["summary"]["reconcile_status"] == "quiesced"
for row in data["rows"]:
    assert row["store_rc"] == 1 and row["gen_rc"] == 1 and row["slot_rc"] == 1
    assert row["skew_code"] == 0
PY

log "done"
