After partial store recovery, checkpoint and mount probes can read settled while retired keys reappear under stale generation tags. Echo waves disagree on closure stamps and revival facets even when the aggregate line looks mostly fine.

Make sources under `/app` emit `/app/output/revival_report.json`. Use the locked release workspace build command documented in `/app/docs/build_hints.txt`, then run `/app/target/release/tv`. Wave ids are listed in `/app/docs/wave_ids.txt`.

The report uses rows and summary with wave_id, store_rc, gen_rc, slot_rc, skew_code, facet_hex, rows_total, reconcile_status, span_band, and trace_digest as defined in `/app/docs/notes.md` (mirror pairs and coherent versus incoherent rules there). The module comment above `/app/m3/k82/src/main.rs` defines span_band and trace_digest reduction; read that header instead of hand-writing JSON. Static or manual JSON writes are not sufficient; the verifier rebuilds from fixed sources and reruns the driver.

Verifier tests rebuild from sources, run the driver, and validate the report.
